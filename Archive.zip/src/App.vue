<script setup>
import TheTable from "./components/table.vue";
</script>

<template>
  <div id="app">
    <TheTable />
  </div>
</template>